<template>
    <div class="PhanChanTrang">
        <p>Copyright &copy; 2024 Library. All Rights</p>
        <p>Reserved. <a href="###">Terms Of Use</a> | <a href="###">Privacy Policy</a></p>
        <p>
            Social Media 
            <img src="../../facebook.png" alt="facebook" class="logoSocialMedia">
            <img src="../../instagram.png" alt="instagram" class="logoSocialMedia">
            <img src="../../telegram.png" alt="telegram" class="logoSocialMedia">
            <img src="../../tik-tok.png" alt="tik-tok" class="logoSocialMedia">
            <img src="../../twitter.png" alt="twitter" class="logoSocialMedia">
        </p>
    </div>
</template>
<style>
    .logoSocialMedia{
        margin-left: 3vh;
        width: 3vh;
        height: 3vh;
        cursor: pointer;
    }
    .PhanChanTrang{
        background-color: rgb(19, 31, 41);
        color: aliceblue;
        width: 100vw;
        height: auto;
        align-content: center;
        justify-content: center;
        z-index: 2;
        position: relative;
        text-align: center;
        padding: 5vh 0vh 5vh 0vh;
        border: 1px solid rgb(187, 187, 187);
    }
</style>