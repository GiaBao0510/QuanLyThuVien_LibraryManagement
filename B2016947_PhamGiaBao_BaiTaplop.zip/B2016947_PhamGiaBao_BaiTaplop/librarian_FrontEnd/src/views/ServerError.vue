<template>
    <header></header>
    <body>
        <head></head>
        <main>
            <h1>500</h1>
            <h3>INTERNAL SERVER ERROR</h3>
            <p>
                We encountered an error and can't fulfill the request.
                The error has been traced and we will word hard to get a fix out 
                as soon as possible. See the status message below for additional information.
            </p>
        </main>
        <footer></footer>
    </body>
</template>